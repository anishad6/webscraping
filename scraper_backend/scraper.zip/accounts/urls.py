from django.urls import path
from .views import google_login

app_name = 'accounts'

urlpatterns = [
    path('api/auth/google/', google_login, name='google_login'),
]