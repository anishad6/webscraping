import React from 'react';
import ReactDOM from 'react-dom/client';
import { GoogleOAuthProvider } from '@react-oauth/google';
import App from './App';

// Replace this with your actual Google OAuth Client ID from Google Cloud Console
const GOOGLE_CLIENT_ID = "126474618620-l23p7893eu8uprgcfcuon1fsqvl1087g.apps.googleusercontent.com126474618620-l23p7893eu8uprgcfcuon1fsqvl1087g.apps.googleusercontent.com";

const root = ReactDOM.createRoot(document.getElementById('root'));

root.render(
  <GoogleOAuthProvider clientId={GOOGLE_CLIENT_ID}>
    <App />
  </GoogleOAuthProvider>
);
