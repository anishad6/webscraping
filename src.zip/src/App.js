import { GoogleOAuthProvider } from '@react-oauth/google';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './components/Login';

// import Login from './components/Login';  // Verify path is correct
import Dashboard from './components/Dashboard';
import Scraper from './components/Scraper';
import Navbar from './components/Navbar';

function App() {
  return (
    // <GoogleOAuthProvider clientId="126474618620-l23p7893eu8uprgcfcuon1fsqvl1087g.apps.googleusercontent.com">
    // <GoogleOAuthProvider clientId={process.env.REACT_APP_GOOGLE_CLIENT_ID}>
    // <GoogleOAuthProvider 
    //   clientId="126474618620-l23p7893eu8uprgcfcuon1fsqvl1087g.apps.googleusercontent.com"
    // >
    <GoogleOAuthProvider 
      clientId="YOUR_CLIENT_ID.apps.googleusercontent.com"
      onScriptLoadError={() => console.log('Script load error')}
      onScriptLoadSuccess={() => console.log('Script load success')}
      >
      <Router>
        <Navbar />
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/scraper" element={<Scraper />} />
        </Routes>
      </Router>
    </GoogleOAuthProvider>
  );
}

export default App;  // Must have this