import React from 'react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav style={{padding: '10px 20px', borderBottom: '1px solid #ddd', display: 'flex', gap: '12px'}}>
      <Link to="/">Login</Link>
      <Link to="/dashboard">Dashboard</Link>
      <Link to="/scraper">Scraper</Link>
    </nav>
  );
}
