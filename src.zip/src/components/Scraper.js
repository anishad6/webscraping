// src/components/Scraper.js
import React, { useState } from 'react';
import { Button, TextField, CircularProgress, Box, Typography } from '@mui/material';
import axios from 'axios';

const Scraper = () => {
  const [url, setUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [scrapedData, setScrapedData] = useState([]);
  const [error, setError] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError(null);
    
    try {
      const token = localStorage.getItem('access_token');
      const response = await axios.post('http://localhost:8000/api/scrape-jobs/', 
        { url },
        {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        }
      );
      
      // Fetch the scraped data
      const dataResponse = await axios.get('http://localhost:8000/api/scraped-data/', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      setScrapedData(dataResponse.data);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to scrape website');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Box sx={{ padding: 3 }}>
      <Typography variant="h4" gutterBottom>Website Scraper</Typography>
      
      <form onSubmit={handleSubmit}>
        <TextField
          fullWidth
          label="Website URL"
          variant="outlined"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          margin="normal"
          required
        />
        <Button 
          type="submit" 
          variant="contained" 
          color="primary"
          disabled={isLoading}
          sx={{ mt: 2 }}
        >
          {isLoading ? <CircularProgress size={24} /> : 'Scrape Website'}
        </Button>
      </form>
      
      {error && (
        <Typography color="error" sx={{ mt: 2 }}>
          {error}
        </Typography>
      )}
      
      <Box sx={{ mt: 4 }}>
        {scrapedData.length > 0 ? (
          <>
            <Typography variant="h6" gutterBottom>Scraped Results</Typography>
            {scrapedData.map((item) => (
              <Box key={item.id} sx={{ mb: 2, p: 2, border: '1px solid #ddd', borderRadius: 1 }}>
                <Typography variant="subtitle1">
                  <a href={item.url} target="_blank" rel="noopener noreferrer">
                    {item.title}
                  </a>
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {item.content}
                </Typography>
              </Box>
            ))}
          </>
        ) : (
          <Typography>No scraped data yet. Enter a URL to scrape.</Typography>
        )}
      </Box>
    </Box>
  );
};

export default Scraper;