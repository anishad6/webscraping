import { useState } from 'react';  // Add this import
import { GoogleOAuthProvider, GoogleLogin } from '@react-oauth/google';
import { useNavigate } from 'react-router-dom';
import axios from 'axios';
import { Box, CircularProgress, Typography, Alert } from '@mui/material';

const Login = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleSuccess = async (credentialResponse) => {
    setLoading(true);
    setError(null);
    
    try {
      const response = await axios.post(
        'http://localhost:8000/api/auth/google/', 
        { token: credentialResponse.credential },
        {
          headers: { 'Content-Type': 'application/json' }
        }
      );

      localStorage.setItem('access_token', response.data.token);
      navigate('/dashboard');
    } catch (error) {
      setError(error.response?.data?.error || 'Login failed');
      console.error('Login error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleError = () => {
    setError('Google login failed. Please try again.');
  };

  return (
    <Box sx={{ 
      display: 'flex',
      justifyContent: 'center',
      alignItems: 'center',
      height: '100vh',
      flexDirection: 'column',
      gap: 2
    }}>
      <Typography variant="h4" gutterBottom>
        Welcome to Scraper App
      </Typography>
      
      <GoogleOAuthProvider
        clientId="126474618620-l23p7893eu8uprgcfcuon1fsqvl1087g.apps.googleusercontent.com"
      >
        {loading ? (
          <CircularProgress size={60} />
        ) : (
          <GoogleLogin
            onSuccess={handleSuccess}
            onError={handleError}
            shape="pill"
            size="large"
            text="continue_with"
            theme="filled_blue"
          />
        )}
      </GoogleOAuthProvider>
      
      {error && (
        <Alert severity="error" sx={{ width: '100%', maxWidth: 400 }}>
          {error}
        </Alert>
      )}
      
      <Typography variant="body2" color="text.secondary" sx={{ mt: 2 }}>
        By continuing, you agree to our Terms of Service and Privacy Policy
      </Typography>
    </Box>
  );
};

export default Login;