import React from 'react';

export default function Dashboard({ user }) {
  return <div>Welcome, {user?.name || user?.email}</div>;
}
